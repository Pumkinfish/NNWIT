package mcp.mobius.waila.api.component;

import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

@ApiSide.ClientOnly
public class SpriteComponent implements ITooltipComponent {

    public SpriteComponent(Identifier id, int width, int height) {
        this.id = id;
        this.width = width;
        this.height = height;
    }

    private final Identifier id;
    private final int width, height;

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void render(GuiGraphicsExtractor ctx, int x, int y, DeltaTracker delta) {
        ctx.blitSprite(RenderPipelines.GUI_TEXTURED, id, x, y, width, height);
    }

}
