package mcp.mobius.waila.plugin.trenergy.provider;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.data.EnergyData;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.jspecify.annotations.Nullable;
import team.reborn.energy.api.EnergyStorage;

public enum EnergyStorageProvider implements IDataProvider<BlockEntity> {

    INSTANCE;

    @Nullable
    @SuppressWarnings("NullableProblems")
    private BlockApiCache<EnergyStorage, @Nullable Direction> cache;

    @Override
    public void appendData(IDataWriter data, IServerAccessor<BlockEntity> accessor, IPluginConfig config) {
        data.add(EnergyData.TYPE, res -> {
            if (cache == null || cache.getBlockEntity() != accessor.getTarget()) {
                cache = BlockApiCache.create(EnergyStorage.SIDED, accessor.getLevel(), accessor.getTarget().getBlockPos());
            }

            @SuppressWarnings("DataFlowIssue")
            var storage = cache.find(accessor.getTarget().getBlockState(), null);

            if (storage != null) {
                res.add(EnergyData.of(storage.getAmount(), storage.getCapacity()));
            }
        });
    }

}
